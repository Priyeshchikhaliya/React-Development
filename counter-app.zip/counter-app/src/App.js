import "./Mycss.css";
import Navbar from "./Navbar";
import Counter from "./Counter";

export default function App() {
	return (
		<div>
			<Navbar />
			<Counter />
		</div>
	);
}
