import React from "react";
import "./Mycss.css";

export default function Navbar() {
  return (
      <nav className="navbar">
        <h1 className="navbar-title">Counter</h1>
      </nav>
  );
}
