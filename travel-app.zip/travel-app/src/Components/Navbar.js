import React from "react";
import "../Mycss.css";

export default function Navbar() {
  return (
      <nav className="navbar">
        <h1 className="navbar-title">🌎mytraveljournal.com</h1>
      </nav>
  );
}
