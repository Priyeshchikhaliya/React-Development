import './Mycss.css';
import Navbar from './Navbar'
import Meme from './Meme'

export default function App() {
  return (
    <div>
      <Navbar/>
      <Meme/>
    </div>
  );
}

